var PLAY = 1
var END = 0
var gameState = PLAY

var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var foodGroup, obstacleGroup
var ground
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}


function setup() {
  createCanvas(600, 200);
  monkey = createSprite(50,140,30,40);
  monkey.addAnimation("running",monkey_running);

  monkey.scale=0.1;
ground = createSprite(200,195,1200,20);
  ground.x = ground.width /2;
  
  score=0
  
 // monkey.setCollider("rectangle",0,0,monkey.width,monkey.height);
//  monkey.debug = true
  obstaclesGroup = createGroup();
  
  foodGroup = createGroup(); 
 // score=0
  
}


function draw() {
  background("lightgreen")
  fill("red")
  text("Score: "+ score, 450,50);
  
  if(gameState === PLAY){
   //  monkey.changeAnimation("running",monkey_running);
    
    ground.velocityX = -4
    
     score = score + Math.round(getFrameRate()/60);
     if(keyDown("space")){
       
       monkey.velocityY=-10;
     }
    monkey.velocityY+=0.5;
     if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
    
   if(foodGroup.isTouching(monkey)){
     
       score=score+1;
   }
    
    spawnObstacles();
     spawnBanana();
    if(obstaclesGroup.isTouching(monkey)){
        gameState = END;
  }
  }
  else if (gameState === END) {
      ground.velocityX = 0;
      monkey.velocityY = 0
    obstaclesGroup.setLifetimeEach(-1);
     foodGroup.setLifetimeEach(-1);
     obstaclesGroup.setVelocityXEach(0);
    foodGroup.setVelocityXEach(0);
   }
  
  
  
  monkey.collide(ground);
  
  drawSprites();
}


function spawnObstacles(){
   if (frameCount % 60 === 0){
   var obstacle = createSprite(550,170,10,50);
     obstacle.addImage(obstaceImage);
     obstacle.scale=0.2   ;
   obstacle.velocityX=-6
         //obstacle.scale = 0.5;
    obstacle.lifetime = 200;
  obstaclesGroup.add(obstacle);
     
}
 }

function spawnBanana(){
  if(frameCount%100===0){
  banana=createSprite(600,Math.round(random(20,60)),30,30);
    banana.addImage(bananaImage)
    banana.scale=0.1
    banana.lifetime = 200;
    banana.velocityX=-6;
    foodGroup.add(banana)
    
    
  }
  
  
}
